
  <footer class="section">
    <div class="center grey-text">&copy; Megan Stoffel, Titus Smith, Vineeth Suresh</div>
  </footer>
</body>