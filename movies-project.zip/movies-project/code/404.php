 <?php

	include('config/db_connect.php');
?>

<!DOCTYPE html>
<html>
	
	<?php include('templates/header.php'); ?>
	<h4 style="text-align:center">This page does not exist.</h4>

</html>